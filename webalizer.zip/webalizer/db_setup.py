import mysql.connector

def create_database_and_tables():
    try:
        # Connect to MySQL server (XAMPP default)
        conn = mysql.connector.connect(
            host='localhost',
            user='root',       # XAMPP default user
            password=''        # XAMPP default no password; change if you set one
        )
        cursor = conn.cursor()

        # Create database if not exists
        cursor.execute("CREATE DATABASE IF NOT EXISTS employee_system")
        cursor.execute("USE employee_system")

        # Create users table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(100) NOT NULL
        )
        """)

        # Create employees table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INT AUTO_INCREMENT PRIMARY KEY,
            fullname VARCHAR(100) NOT NULL,
            age INT NOT NULL,
            address VARCHAR(255),
            contact VARCHAR(30),
            gender ENUM('Male', 'Female'),
            face_encoding LONGBLOB NOT NULL,
            qrcode_path VARCHAR(255)
        )
        """)

        # Create attendance logs table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT,
            log_date DATE,
            time_in TIME NULL,
            time_out TIME NULL,
            FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
        """)

        # Insert default admin user if not exists
        cursor.execute("SELECT * FROM users WHERE username='admin'")
        if cursor.fetchone() is None:
            cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", ('admin', 'admin123'))
            conn.commit()

        print("Database and tables setup completed successfully.")

    except mysql.connector.Error as err:
        print(f"Error setting up database: {err}")

    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    create_database_and_tables()
