import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from tkinter import filedialog
import cv2
import face_recognition
import numpy as np
import mysql.connector
import qrcode
from PIL import Image, ImageTk
from pyzbar import pyzbar
import datetime
import io
import os
import pandas as pd
import threading

# ---------- CONFIGURATION ----------
DB_HOST = 'localhost'
DB_USER = 'root'       # Adjust if you have MySQL user/pass
DB_PASSWORD = ''       # Adjust password accordingly
DB_NAME = 'employee_system'

# Folder to save QR codes
QR_CODES_DIR = 'qr_codes'
if not os.path.exists(QR_CODES_DIR):
    os.makedirs(QR_CODES_DIR)

# Exported Excel Folder
EXCEL_EXPORT_DIR = 'exports'
if not os.path.exists(EXCEL_EXPORT_DIR):
    os.makedirs(EXCEL_EXPORT_DIR)

# ----------------------------------

# ---------------- DATABASE SETUP --------------------
def create_database_and_tables():
    # Connect to MySQL server and create DB and tables if not exists
    try:
        conn = mysql.connector.connect(host=DB_HOST, user=DB_USER, password=DB_PASSWORD)
        cursor = conn.cursor()
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}")
        cursor.execute(f"USE {DB_NAME}")

        # Users table (for login)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(100) NOT NULL
        )
        """)

        # Employees table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INT AUTO_INCREMENT PRIMARY KEY,
            fullname VARCHAR(100) NOT NULL,
            age INT NOT NULL,
            address VARCHAR(255),
            contact VARCHAR(30),
            gender ENUM('Male', 'Female'),
            face_encoding LONGBLOB NOT NULL,
            qrcode_path VARCHAR(255)
        )
        """)

        # Attendance logs
        cursor.execute("""
    CREATE TABLE IF NOT EXISTS attendance_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT,
        log_date DATE,
        time_in TIME NULL,
        time_out TIME NULL,
        FOREIGN KEY (employee_id) REFERENCES employees(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
       )
       """)

        # Insert default admin user if not exists
        cursor.execute("SELECT * FROM users WHERE username='admin'")
        if cursor.fetchone() is None:
            cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", ('admin', 'admin123'))  # Password plaintext (simple)
            conn.commit()

        cursor.close()
        conn.close()
    except Exception as e:
        messagebox.showerror("DB Setup Error", f"Error setting up database: {str(e)}")

# -------------- DB CONNECTION ------------------
def get_db_connection():
    try:
        return mysql.connector.connect(
            host=DB_HOST, 
            user=DB_USER, 
            password=DB_PASSWORD, 
            database=DB_NAME
        )
    except mysql.connector.Error as e:
        messagebox.showerror("Database Connection Error", f"Failed to connect to database: {str(e)}")
        return None

# ------------- Helper functions --------------

def encode_face(image):
    try:
        # Ensure image is not None
        if image is None:
            print("Error: Image is None")
            return None
            
        # Make sure image is in the right format (8-bit)
        if image.dtype != np.uint8:
            print(f"Converting image from {image.dtype} to uint8")
            image = np.array(image, dtype=np.uint8)
            
        # Check if image is grayscale and convert to RGB if needed
        if len(image.shape) == 2:
            print("Converting grayscale to RGB")
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        # If image is BGR (OpenCV default), convert to RGB
        elif len(image.shape) == 3 and image.shape[2] == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
        # Verify image format before processing
        if image.shape[2] != 3:
            print(f"Invalid image channels: {image.shape}")
            return None
            
        # Get face encodings
        face_locations = face_recognition.face_locations(image)
        if len(face_locations) == 0:
            print("No face detected in the image")
            return None
            
        encodings = face_recognition.face_encodings(image, face_locations)
        if len(encodings) > 0:
            return encodings[0]
        else:
            print("No encodings found for detected face")
            return None
    except Exception as e:
        print(f"Error in encode_face: {str(e)}")
        return None


def save_employee_to_db(fullname, age, address, contact, gender, face_encoding_bytes, qrcode_path):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        sql = "INSERT INTO employees (fullname, age, address, contact, gender, face_encoding, qrcode_path) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(sql, (fullname, age, address, contact, gender, face_encoding_bytes, qrcode_path))
        conn.commit()
        emp_id = cursor.lastrowid
        cursor.close()
        conn.close()
        return emp_id
    except Exception as e:
        messagebox.showerror("Database Error", f"Failed to save employee: {e}")
        return None

def get_all_employees():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM employees")
        rows = cursor.fetchall()
        cursor.close()
        conn.close()
        return rows
    except Exception as e:
        messagebox.showerror("Database Error", f"Failed to fetch employees: {e}")
        return []

def get_employee_by_id(emp_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM employees WHERE id=%s", (emp_id,))
        row = cursor.fetchone()
        cursor.close()
        conn.close()
        return row
    except Exception as e:
        messagebox.showerror("Database Error", f"Failed to fetch employee: {e}")
        return None

def get_user(username):
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username=%s", (username,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        return user
    except Exception as e:
        messagebox.showerror("Database Error", f"Failed to fetch user: {e}")
        return None

def add_attendance_log(employee_id, date, time_in=None, time_out=None):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        # Check if log for date exists
        cursor.execute("SELECT * FROM attendance_logs WHERE employee_id=%s AND log_date=%s", (employee_id, date))
        record = cursor.fetchone()
        if record is None:
            # Insert new record
            cursor.execute("INSERT INTO attendance_logs (employee_id, log_date, time_in, time_out) VALUES (%s, %s, %s, %s)", (employee_id, date, time_in, time_out))
        else:
            # Update existing
            if time_in:
                cursor.execute("UPDATE attendance_logs SET time_in=%s WHERE id=%s", (time_in, record[0]))
            if time_out:
                cursor.execute("UPDATE attendance_logs SET time_out=%s WHERE id=%s", (time_out, record[0]))
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        messagebox.showerror("Database Error", f"Failed to add/update attendance log: {e}")

def get_attendance_logs_by_date(date):
    """Fetch attendance logs for a specific date with employee details
    
    Args:
        date (date): Date object to query logs for
    
    Returns:
        list: List of dictionaries containing log records, or empty list on error
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT 
                al.id,
                al.employee_id,
                al.log_date,
                al.time_in,
                al.time_out,
                e.fullname,
                e.contact
            FROM attendance_logs al
            LEFT JOIN employees e ON al.employee_id = e.id
            WHERE al.log_date = %s
            ORDER BY e.fullname, al.time_in
        """, (date,))
        
        logs = cursor.fetchall()
        return logs
        
    except Exception as e:
        messagebox.showerror("Database Error", 
                           f"Failed to fetch attendance logs:\n{str(e)}")
        return []
        
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()

# -------------------- Export to Excel --------------------

def export_employee_info_to_excel(employee):
    try:
        data = {
            'ID': [employee['id']],
            'Full Name': [employee['fullname']],
            'Age': [employee['age']],
            'Address': [employee['address']],
            'Contact': [employee['contact']],
            'Gender': [employee['gender']]
        }
        df = pd.DataFrame(data)
        filepath = os.path.join(EXCEL_EXPORT_DIR, f"employee_{employee['id']}_{employee['fullname'].replace(' ', '_')}.xlsx")
        df.to_excel(filepath, index=False)

        messagebox.showinfo("Export Successful", f"Employee info exported to {filepath}")
    except Exception as e:
        messagebox.showerror("Export Error", f"Failed to export to Excel: {e}")

# ----------------- QR Code Functions ----------------------

def generate_qr_code(data, filename):
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=2)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(filename)

# ------------------- Face Recognition Login -------------------

def recognize_face_and_get_employee():
    try:
        cam = cv2.VideoCapture(0)
        if not cam.isOpened():
            messagebox.showerror("Camera Error", "Failed to open camera. Please check your webcam connection.")
            return None
            
        recognized_employee = None
        messagebox.showinfo("Face Recognition", "Press 'q' to quit scanning. Press 's' to scan your face.")

        while True:
            ret, frame = cam.read()
            if not ret:
                messagebox.showerror("Camera Error", "Failed to access camera.")
                break

            cv2.imshow("Face Recognition - Press 's' to scan face, 'q' to quit", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s'):
                # Encode face
                face_encoding = encode_face(frame)
                if face_encoding is None:
                    messagebox.showwarning("Face Not Found", "No face detected. Try again.")
                    continue

                employees = get_all_employees()
                for emp in employees:
                    emp_encoding = np.frombuffer(emp['face_encoding'], dtype=np.float64)
                    matches = face_recognition.compare_faces([emp_encoding], face_encoding)
                    if matches[0]:
                        recognized_employee = emp
                        break

                if recognized_employee:
                    messagebox.showinfo("Recognized", f"Welcome {recognized_employee['fullname']}!")
                    break
                else:
                    messagebox.showwarning("Not Recognized", "Face not recognized in the system.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")
        return None
    finally:
        if 'cam' in locals() and cam is not None:
            cam.release()
        cv2.destroyAllWindows()
        
    return recognized_employee

# ------------------ Main Application Class ----------------------

class EmployeeApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Employee Face Recognition & Attendance System")
        self.geometry("800x600")
        self.resizable(False, False)
        self.employee_face_encodings = []
        self.current_user = None
        self.current_employee = None
        self.frames = {}
        self.init_ui()

    def init_ui(self):
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        for F in (LoginPage, DashboardPage, RegisterEmployeePage, ViewEmployeesPage, ViewLogsPage, QRCodeScannerPage):
            frame = F(parent=container, controller=self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(LoginPage)

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

    def login(self, username, password):
        user = get_user(username)
        if user and user['password'] == password:
            self.current_user = user
            self.show_frame(DashboardPage)
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")

    def face_recognition_login(self):
        emp = recognize_face_and_get_employee()
        if emp:
            self.current_employee = emp
            export_employee_info_to_excel(emp)
        else:
            messagebox.showwarning("Login Failed", "Face recognition login failed.")

    def logout(self):
        self.current_user = None
        self.current_employee = None
        self.show_frame(LoginPage)

# --------------------- Login Page --------------------
class LoginPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # Outer container frame
        container = tk.Frame(self)
        container.pack(expand=True, padx=20, pady=20)

        # Left side - Image
        left_frame = tk.Frame(container)
        left_frame.grid(row=0, column=0, padx=20)

        image_path = "employee.jpg"  # Make sure this file exists in your project directory

        if os.path.exists(image_path):
            img = Image.open(image_path)
            img = img.resize((200, 200), Image.Resampling.LANCZOS)
            self.photo = ImageTk.PhotoImage(img)
            self.photo_label = tk.Label(left_frame, image=self.photo)
            self.photo_label.pack()
        else:
            tk.Label(left_frame, text="[Employee Photo Not Found]").pack()

        # Right side - Form and Buttons
        right_frame = tk.Frame(container)
        right_frame.grid(row=0, column=1, padx=20)

        title = tk.Label(right_frame, text="Admin System Login", font=("Helvetica", 20, "bold"), fg="#4b2e1f")
        title.pack(pady=10)

        frm_form = tk.Frame(right_frame)
        frm_form.pack(pady=10)

        lbl_username = tk.Label(frm_form, text="Username:", font=("Helvetica", 14))
        lbl_username.grid(row=0, column=0, sticky="e", pady=5)
        self.ent_username = tk.Entry(frm_form, font=("Helvetica", 14))
        self.ent_username.grid(row=0, column=1, pady=5)

        lbl_password = tk.Label(frm_form, text="Password:", font=("Helvetica", 14))
        lbl_password.grid(row=1, column=0, sticky="e", pady=5)
        self.ent_password = tk.Entry(frm_form, font=("Helvetica", 14), show="*")
        self.ent_password.grid(row=1, column=1, pady=5)

        # Buttons
        btn_login = tk.Button(right_frame, text="Login", font=("Helvetica", 14), bg="#d4af37", fg="white",
                              activebackground="#4b2e1f", command=self.perform_login)
        btn_login.pack(pady=5, fill="x")

        btn_face_login = tk.Button(right_frame, text="Login with Face Recognition", font=("Helvetica", 14),
                                   bg="#4b2e1f", fg="white", activebackground="#d4af37",
                                   command=self.face_login)
        btn_face_login.pack(pady=5, fill="x")

        btn_forgot = tk.Button(right_frame, text="Forgot Password?", font=("Helvetica", 12),
                               fg="blue", command=self.forgot_password, relief=tk.FLAT)
        btn_forgot.pack(pady=5)

    def perform_login(self):
        username = self.ent_username.get()
        password = self.ent_password.get()
        if not username or not password:
            messagebox.showwarning("Validation", "Please enter username and password.")
            return
        self.controller.login(username, password)

    def face_login(self):
        threading.Thread(target=self.controller.face_recognition_login).start()

    def forgot_password(self):
        messagebox.showinfo("Forgot Password", "Please contact the administrator to reset your password.")


# -------------------- Dashboard Page ---------------------

class DashboardPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        self.configure(bg="#f0f2f5")  # Light gray background

        # Sidebar
        sidebar = tk.Frame(self, bg="#2c3e50", width=250)
        sidebar.pack(side="left", fill="y")

        # Title
        title = tk.Label(sidebar, text="ADMIN DASHBOARD", font=("Segoe UI", 14, "bold"),
                         bg="#2c3e50", fg="#ecf0f1")
        title.pack(pady=20)

        # Employee photo (placeholder)
        image_path = "employee.jpg"
        if os.path.exists(image_path):
            img = Image.open(image_path)
            img = img.resize((100, 100), Image.Resampling.LANCZOS)
            self.photo = ImageTk.PhotoImage(img)
            img_label = tk.Label(sidebar, image=self.photo, bg="#2c3e50")
            img_label.pack(pady=10)
        else:
            tk.Label(sidebar, text="[No Photo]", fg="#ecf0f1", bg="#2c3e50").pack()

        # Employee name (placeholder)
        tk.Label(sidebar, text="Welcome, Admin", font=("Segoe UI", 11),
                 fg="#ecf0f1", bg="#2c3e50").pack(pady=5)

        # Buttons in sidebar
        btn_style = {
            "font": ("Segoe UI", 10),
            "bg": "#34495e",
            "fg": "#ecf0f1",
            "activebackground": "#1abc9c",
            "activeforeground": "#ffffff",
            "width": 22,
            "bd": 0,
            "relief": "flat",
            "cursor": "hand2"
        }

        tk.Button(sidebar, text="Register Employee", command=lambda: controller.show_frame(RegisterEmployeePage), **btn_style).pack(pady=5)
        tk.Button(sidebar, text="View Employee Logs", command=lambda: controller.show_frame(ViewLogsPage), **btn_style).pack(pady=5)
        tk.Button(sidebar, text="View Employees", command=lambda: controller.show_frame(ViewEmployeesPage), **btn_style).pack(pady=5)
        tk.Button(sidebar, text="QR Code Scanner", command=lambda: controller.show_frame(QRCodeScannerPage), **btn_style).pack(pady=5)
        tk.Button(sidebar, text="Logout", command=controller.logout, **btn_style).pack(pady=20)

        # Main area
        main_area = tk.Frame(self, bg="#f0f2f5")
        main_area.pack(side="left", expand=True, fill="both")

        dashboard_label = tk.Label(main_area, text="ADMIN DASHBOARD", font=("Segoe UI", 20, "bold"), fg="#2c3e50", bg="#f0f2f5")
        dashboard_label.pack(pady=50)


# ------------------- Register Employee Page ------------------------

class RegisterEmployeePage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.face_image = None
        self.face_encoding = None

        title = tk.Label(self, text="Register Employee", font=("Helvetica", 24, "bold"))
        title.pack(pady=10)

        form_frame = tk.Frame(self)
        form_frame.pack(pady=10)

        # Full name
        tk.Label(form_frame, text="Full Name:", font=("Helvetica", 14)).grid(row=0, column=0, sticky='e')
        self.entry_fullname = tk.Entry(form_frame, font=("Helvetica", 14), width=30)
        self.entry_fullname.grid(row=0, column=1)

        # Age
        tk.Label(form_frame, text="Age:", font=("Helvetica", 14)).grid(row=1, column=0, sticky='e')
        self.entry_age = tk.Entry(form_frame, font=("Helvetica", 14), width=10)
        self.entry_age.grid(row=1, column=1, sticky='w')

        # Address
        tk.Label(form_frame, text="Address:", font=("Helvetica", 14)).grid(row=2, column=0, sticky='e')
        self.entry_address = tk.Entry(form_frame, font=("Helvetica", 14), width=40)
        self.entry_address.grid(row=2, column=1)

        # Contact
        tk.Label(form_frame, text="Contact Number:", font=("Helvetica", 14)).grid(row=3, column=0, sticky='e')
        self.entry_contact = tk.Entry(form_frame, font=("Helvetica", 14), width=20)
        self.entry_contact.grid(row=3, column=1, sticky='w')

        # Gender
        tk.Label(form_frame, text="Gender:", font=("Helvetica", 14)).grid(row=4, column=0, sticky='e')
        self.gender_var = tk.StringVar(value='Male')
        tk.Radiobutton(form_frame, text='Male', variable=self.gender_var, value='Male', font=("Helvetica", 14)).grid(row=4, column=1, sticky='w')
        tk.Radiobutton(form_frame, text='Female', variable=self.gender_var, value='Female', font=("Helvetica", 14)).grid(row=4, column=1, sticky='e')

        # Capture Face Button
        self.btn_capture_face = tk.Button(self, text="Capture Face (Webcam)", font=("Helvetica", 14), command=self.capture_face)
        self.btn_capture_face.pack(pady=10)

        # Face Preview Label
        self.lbl_face_preview = tk.Label(self)
        self.lbl_face_preview.pack()

        # Register Button
        self.btn_register = tk.Button(self, text="Register Employee", font=("Helvetica", 16), command=self.register_employee)
        self.btn_register.pack(pady=10)

        # Back Button
        self.btn_back = tk.Button(self, text="Back to Dashboard", font=("Helvetica", 14),
                                command=lambda: controller.show_frame(DashboardPage))
        self.btn_back.pack(pady=5)

    def encode_face(self, image):
        """Helper method to encode a face from an image."""
        try:
            face_encodings = face_recognition.face_encodings(image)
            if len(face_encodings) > 0:
                return face_encodings[0]
            return None
        except Exception as e:
            print(f"Face encoding error: {str(e)}")
            return None

    def capture_face(self):
        """Capture employee face using webcam with real-time face detection feedback."""
        cam = None
        try:
            # Try different backends if default fails
            cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # Try DirectShow first
            
            if not cam.isOpened():
                # Try default backend as fallback
                cam = cv2.VideoCapture(0)
                
            if not cam.isOpened():
                messagebox.showerror("Camera Error", "Failed to open camera. Please check your webcam connection.")
                return
                
            # Set properties for better compatibility
            cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            
            # Inform user about controls
            messagebox.showinfo("Capture Face", "Position your face in the frame.\n• Press 's' to capture\n• Press 'q' to cancel")
            captured = False
            
            # Main capture loop
            while True:
                ret, frame = cam.read()
                if not ret or frame is None:
                    messagebox.showerror("Camera Error", "Failed to read frame from camera.")
                    break
                    
                # Ensure frame is in the right format and convert to RGB
                if frame.dtype != np.uint8:
                    frame = np.array(frame, dtype=np.uint8)
                
                # Convert to RGB for face_recognition (which requires RGB)
                rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                
                # Create a copy for display with face detection overlay
                display_frame = frame.copy()
                
                try:
                    # Detect faces for visual feedback
                    face_locations = face_recognition.face_locations(rgb_frame)
                    
                    # Draw rectangle around detected faces
                    for (top, right, bottom, left) in face_locations:
                        cv2.rectangle(display_frame, (left, top), (right, bottom), (0, 255, 0), 2)
                        # Add text indicator
                        cv2.putText(display_frame, "Face Detected", (left, top - 10), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                    
                    # Show guidance text if no face detected
                    if not face_locations:
                        cv2.putText(display_frame, "No face detected - Please position your face in frame", 
                                   (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                except Exception as e:
                    print(f"Face detection error: {str(e)}")
                    # Continue without face detection if it fails
                    pass
                    
                # Display frame with overlays
                cv2.imshow("Face Capture - Press 's' to capture, 'q' to quit", display_frame)
                key = cv2.waitKey(1) & 0xFF
                
                # Handle key presses
                if key == ord('s'):
                    # Get face encoding from the RGB frame
                    face_encoding = self.encode_face(rgb_frame)  # Changed to use self.encode_face
                    if face_encoding is None:
                        messagebox.showwarning("Face Not Found", "No face detected or encoding failed. Please try again with better lighting.")
                        continue
                        
                    # Store the encoding and image
                    self.face_encoding = face_encoding
                    self.face_image = frame.copy()
                    
                    # Show preview (convert to RGB for PIL)
                    preview_img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    img_pil = Image.fromarray(preview_img)
                    img_pil = img_pil.resize((200, 200))
                    self.photo_img = ImageTk.PhotoImage(img_pil)
                    self.lbl_face_preview.configure(image=self.photo_img)
                    
                    messagebox.showinfo("Success", "Face captured successfully!")
                    captured = True
                    break
                    
                elif key == ord('q'):
                    break
                    
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while capturing face: {str(e)}")
            print(f"Face capture error: {str(e)}")
            
        finally:
            # Ensure resources are released
            if cam is not None:
                cam.release()
            cv2.destroyAllWindows()
            
            if not captured:
                messagebox.showinfo("Cancelled", "Face capture was cancelled or unsuccessful.")

    def register_employee(self):
        fullname = self.entry_fullname.get().strip()
        age_str = self.entry_age.get().strip()
        address = self.entry_address.get().strip()
        contact = self.entry_contact.get().strip()
        gender = self.gender_var.get()

        if not fullname or not age_str or not contact or self.face_encoding is None:
            messagebox.showwarning("Input Error", "Please fill all required fields and capture face.")
            return

        try:
            age = int(age_str)
        except ValueError:
            messagebox.showwarning("Input Error", "Age must be a number.")
            return

        # Convert face_encoding to bytes to save in DB
        face_encoding_bytes = self.face_encoding.tobytes()

        # Generate QR code encoding employee ID after saving
        dummy_id = "temp"  # Placeholder for qr code generation path

        emp_id = save_employee_to_db(fullname, age, address, contact, gender, face_encoding_bytes, "")

        if emp_id is None:
            return

        # Generate QR code with employee ID
        qr_data = f"EMPLOYEE_ID:{emp_id}"
        qr_file = os.path.join(QR_CODES_DIR, f"emp_{emp_id}.png")
        generate_qr_code(qr_data, qr_file)

        # Update employee QR code path in DB
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("UPDATE employees SET qrcode_path=%s WHERE id=%s", (qr_file, emp_id))
            conn.commit()
            cursor.close()
            conn.close()
        except Exception as e:
            messagebox.showerror("DB Error", f"Failed to update QR code path: {e}")
            return

        messagebox.showinfo("Success", f"Employee {fullname} registered successfully!")
        # Clear form
        self.entry_fullname.delete(0, 'end')
        self.entry_age.delete(0, 'end')
        self.entry_address.delete(0, 'end')
        self.entry_contact.delete(0, 'end')
        self.face_encoding = None
        self.lbl_face_preview.configure(image='')

# ------------------- View Employees Page ------------------------

class ViewEmployeesPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        title = tk.Label(self, text="Employees", font=("Helvetica", 24, "bold"))
        title.pack(pady=10)

        # Listbox or Treeview for showing employees with scrollbar
        self.tree = ttk.Treeview(self, columns=("ID", "Full Name", "Age", "Contact", "Gender"), show='headings', height=15)
        for col in ("ID", "Full Name", "Age", "Contact", "Gender"):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=130 if col != "Full Name" else 200)
        self.tree.pack(side="left", fill="y")

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side="left", fill="y")

        # Image panel for face picture
        self.face_panel = tk.Label(self)
        self.face_panel.pack(side="left", padx=20)

        # Buttons
        btn_frame = tk.Frame(self)
        btn_frame.pack(side="bottom", fill="x", pady=10)
        btn_back = tk.Button(btn_frame, text="Back to Dashboard", font=("Helvetica", 14),
                             command=lambda: controller.show_frame(DashboardPage))
        btn_back.pack()

        # Bind selecting item event
        self.tree.bind("<<TreeviewSelect>>", self.on_employee_select)

        self.load_employees()

    def load_employees(self):
        self.tree.delete(*self.tree.get_children())
        employees = get_all_employees()
        for emp in employees:
            self.tree.insert("", "end", iid=emp['id'], values=(emp['id'], emp['fullname'], emp['age'], emp['contact'], emp['gender']))

    def on_employee_select(self, event):
        selected = self.tree.focus()
        if selected == "":
            return
        emp_id = int(selected)
        emp = get_employee_by_id(emp_id)
        if emp:
            face_encoding_bytes = emp['face_encoding']
            face_encoding = np.frombuffer(face_encoding_bytes, dtype=np.float64)
            # Usually we don't store entire face image but only encoding.
            # For preview, we might build face image from encoding using demo, but here we can't.
            # Instead, show the QR code image if exists
            qr_path = emp['qrcode_path']
            if qr_path and os.path.exists(qr_path):
                img = Image.open(qr_path)
                img = img.resize((200, 200))
                photo = ImageTk.PhotoImage(img)
                self.face_panel.configure(image=photo)
                self.face_panel.image = photo
            else:
                self.face_panel.configure(text="No QR/Face Image")

# ------------------- View Employee Logs Page ----------------------

class ViewLogsPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        title = tk.Label(self, text="Employee Attendance Logs", font=("Helvetica", 24, "bold"))
        title.pack(pady=10)

        cal_frame = tk.Frame(self)
        cal_frame.pack()

        tk.Label(cal_frame, text="Select Date:", font=("Helvetica", 14)).pack(side="left", padx=5)
        self.selected_date = tk.StringVar()
        self.date_entry = tk.Entry(cal_frame, font=("Helvetica", 14), textvariable=self.selected_date, width=12)
        self.date_entry.pack(side="left")

        btn_load = tk.Button(cal_frame, text="Load Logs", font=("Helvetica", 14), command=self.load_logs)
        btn_load.pack(side="left", padx=5)

        self.tree = ttk.Treeview(self, columns=("Name", "Contact", "Time In", "Time Out"), show='headings', height=20)
        for col in ("Name", "Contact", "Time In", "Time Out"):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=130)
        self.tree.pack(padx=10, pady=10)

        btn_back = tk.Button(self, text="Back to Dashboard", font=("Helvetica", 14),
                             command=lambda: controller.show_frame(DashboardPage))
        btn_back.pack(pady=10)

    def load_logs(self):  # <-- THIS LINE MUST BE INDENTED TO BELONG TO THE CLASS
        date_str = self.selected_date.get().strip()
        try:
            date_obj = datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            messagebox.showwarning("Date Format", "Use YYYY-MM-DD format")
            return

        logs = get_attendance_logs_by_date(date_obj)
        self.tree.delete(*self.tree.get_children())

        for log in logs:
            time_in = log['time_in']
            time_out = log['time_out']

            if isinstance(time_in, datetime.datetime):
                time_in_str = time_in.strftime("%H:%M:%S")
            elif isinstance(time_in, datetime.timedelta):
                total_seconds = int(time_in.total_seconds())
                hours, remainder = divmod(total_seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                time_in_str = f"{hours:02}:{minutes:02}:{seconds:02}"
            else:
                time_in_str = ""

            if isinstance(time_out, datetime.datetime):
                time_out_str = time_out.strftime("%H:%M:%S")
            elif isinstance(time_out, datetime.timedelta):
                total_seconds = int(time_out.total_seconds())
                hours, remainder = divmod(total_seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                time_out_str = f"{hours:02}:{minutes:02}:{seconds:02}"
            else:
                time_out_str = ""

            self.tree.insert("", "end", values=(log['fullname'], log['contact'], time_in_str, time_out_str))



# ------------------ QR Code Scanner Page ---------------------------

class QRCodeScannerPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.camera_running = False
        self.stop_camera = False

        title = tk.Label(self, text="QR Code Scanner", font=("Helvetica", 24, "bold"))
        title.pack(pady=10)

        # Video panel
        self.video_label = tk.Label(self)
        self.video_label.pack()

        # Status label
        self.lbl_status = tk.Label(self, text="Press Start to scan QR code", font=("Helvetica", 14))
        self.lbl_status.pack(pady=5)

        # Buttons
        btn_frame = tk.Frame(self)
        btn_frame.pack(pady=10)

        self.btn_start = tk.Button(btn_frame, text="Start Camera", font=("Helvetica", 14), command=self.start_camera)
        self.btn_start.grid(row=0, column=0, padx=10)

        self.btn_stop = tk.Button(btn_frame, text="Stop Camera", font=("Helvetica", 14), command=self.stop_camera_func, state='disabled')
        self.btn_stop.grid(row=0, column=1, padx=10)

        btn_back = tk.Button(self, text="Back to Dashboard", font=("Helvetica", 14),
                             command=self.go_back)
        btn_back.pack(pady=5)

        self.cap = None

    def start_camera(self):
        if self.camera_running:
            return
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            messagebox.showerror("Camera Error", "Failed to open camera. Please check your webcam connection.")
            return
            
        self.camera_running = True
        self.stop_camera = False
        self.btn_start.config(state='disabled')
        self.btn_stop.config(state='normal')
        self.lbl_status.config(text="Scanning for QR code...")
        self.scan_qr_code_loop()

    def stop_camera_func(self):
        self.stop_camera = True
        self.camera_running = False
        self.btn_start.config(state='normal')
        self.btn_stop.config(state='disabled')
        if self.cap:
            self.cap.release()
            self.cap = None
        self.video_label.config(image='')
        self.lbl_status.config(text="Camera stopped.")

    def scan_qr_code_loop(self):
        if self.stop_camera or not self.camera_running or not self.cap:
            return

        try:
            ret, frame = self.cap.read()
            if not ret:
                self.lbl_status.config(text="Failed to grab frame.")
                self.after(1000, self.scan_qr_code_loop)
                return

            # Convert to RGB and display
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame_rgb)
            imgtk = ImageTk.PhotoImage(image=img)
            self.video_label.imgtk = imgtk
            self.video_label.config(image=imgtk)

            # Scan QR codes
            decoded = pyzbar.decode(frame)
            if decoded:
                self.stop_camera_func()
                qr_data = decoded[0].data.decode('utf-8')
                if qr_data.startswith("EMPLOYEE_ID:"):
                    emp_id = int(qr_data.split(":")[1])
                    emp = get_employee_by_id(emp_id)
                    if emp:
                        self.lbl_status.config(text=f"QR Code matched: {emp['fullname']}")
                        # Prompt time in or time out
                        choice = messagebox.askquestion("Time In/Out", "Is this a Time In? (No means Time Out)")
                        now = datetime.datetime.now()
                        today = now.date()
                        if choice == 'yes':
                            add_attendance_log(emp_id, today, time_in=now.time())
                            messagebox.showinfo("Time In Recorded", f"Time In recorded for {emp['fullname']} at {now.strftime('%H:%M:%S')}")
                        else:
                            add_attendance_log(emp_id, today, time_out=now.time())
                            messagebox.showinfo("Time Out Recorded", f"Time Out recorded for {emp['fullname']} at {now.strftime('%H:%M:%S')}")
                    else:
                        messagebox.showwarning("No Match", "Employee ID not found in system.")
                else:
                    messagebox.showwarning("Invalid QR", "QR code is not a valid Employee ID format.")
        except Exception as e:
            self.lbl_status.config(text=f"Error: {str(e)}")
            print(f"QR scanning error: {str(e)}")

        if not self.stop_camera:
            self.after(30, self.scan_qr_code_loop)

    def go_back(self):
        self.stop_camera_func()
        self.controller.show_frame(DashboardPage)

# ------------------ Run Application ----------------------

if __name__ == "__main__":
    create_database_and_tables()
    app = EmployeeApp()
    app.mainloop()


